# Data move from the old app: supreme

- When: 20261009-203554
- Mode: DRY RUN (rolled back, nothing saved)
- Reconciliation: OK

## Rows in and out

| table | old rows | created | already there | merged | left out |
|---|---:|---:|---:|---:|---:|
| users | 5 | 4 | 1 | 0 | 0 |
| departments | 7 | 7 | 0 | 0 | 0 |
| test_types | 5 | 5 | 0 | 0 | 0 |
| tests | 599 | 594 | 0 | 5 | 0 |
| referring_doctors | 756 | 731 | 0 | 25 | 0 |
| patients | 4959 | 3924 | 0 | 1035 | 0 |
| invoices | 4801 | 4801 | 0 | 0 | 0 |
| invoice_items | 9810 | 9810 | 0 | 0 | 0 |
| payments | 3666 | 3666 | 0 | 0 | 0 |

Referring doctors: 756 spellings grouped into 731 doctors (see doctors.csv). For doctors, 'old rows' counts spellings.

## Decisions applied

- Departments and test types renamed to the new spelling (e.g. ECHO&USG -> Echo & USG, CT-SCAN -> CT scan); X-ray, CT scan and USG are imaging.
- Test names trimmed with spaces collapsed. Same name (any case) in the same department at the same price: merged into one test. Otherwise the later one is renamed '<name> (<Department>)', or '<name> (old #<id>)' if that is taken too.
- Bill lines pointing at a test that no longer exists keep their price as 'Unknown test (old #<id>)' with no test or department.
- Referring doctors grouped on a key (upper case, 'DR' prefix, dots and commas removed, spaces collapsed, single initials joined); SELF, NA, NONE, '-' and blank mean no doctor. Shown under the most used spelling in nice case, with 'Dr.' when any spelling had it.
- Customers merged into one patient only when the name (upper case, spaces collapsed) and the last 10 digits of a 10+ digit mobile match. Patient numbers follow each patient's earliest old customer id.
- A merged patient's details (name, age, gender, mobile, address, C/O, email) come from the latest customer row; created_at from the earliest.
- Ages: whole numbers kept; decimals ('1.5') rounded down to whole years; months/days converted to whole years; anything else left empty.
- Bill numbers: <prefix>/<financial year>/<old number, 6 digits>; a repeated old number keeps the plain form on the lowest old id and the later ones get -B, -C.
- Bill total = old payments.total_amount; the difference from the lines' total is the discount (type 'amount').
- Payments: only old payment rows with an amount above zero; online -> UPI with the note 'Online (old system)'.
- Staff: emails lower-cased; an existing account with the same email is kept as it is and only linked. New accounts keep the old bcrypt password (replaced at first sign-in) and must change it. Admin -> owner, Manager -> admin, Receptionist -> receptionist, User -> technician.
- Running numbers continue after the highest imported patient number and, per financial year, the highest old bill number.
- Staff: bibhasash@gmail.com already had an account here; it was kept as it is and linked to old user #2.
- Counter invoice:2025-26 set to at least 752.
- Counter invoice:2026-27 set to at least 4945.
- Counter patient set to at least 3924.
- age decimal: 30 row(s)

## Issues (53)

- age_unreadable: 1
- invoice_no_duplicate: 3
- test_merged: 5
- test_missing: 26
- test_renamed: 18

| kind | old id | detail |
|---|---:|---|
| test_merged | 71 | 'URINE FOR CHYLOMICRONS' merged into 'URINE FOR CHYLOMICRONS' (old #70): same name, department and price |
| test_renamed | 118 | 'DENGUE IgG CAPTURE ELISA' clashes with old #109 (Pathology, 800.00); named 'DENGUE IgG CAPTURE ELISA (Pathology)' |
| test_renamed | 120 | 'DENGUE IgM CAPTURE ELISA' clashes with old #110 (Pathology, 800.00); named 'DENGUE IgM CAPTURE ELISA (Pathology)' |
| test_renamed | 185 | 'URINE FOR PROTIN' clashes with old #64 (Pathology, 300.00); named 'URINE FOR PROTIN (Pathology)' |
| test_merged | 293 | 'STOOL RE' merged into 'STOOL RE' (old #63): same name, department and price |
| test_renamed | 329 | 'PROGESTERONE' clashes with old #237 (Pathology, 600.00); named 'PROGESTERONE (Pathology)' |
| test_renamed | 359 | 'GLOBULIN' clashes with old #203 (Pathology, 150.00); named 'GLOBULIN (Pathology)' |
| test_merged | 360 | 'ToRCH IgG' merged into 'ToRCH IgG' (old #356): same name, department and price |
| test_renamed | 362 | 'TORCH IGM' clashes with old #148 (Pathology, 1700.00); named 'TORCH IGM (Pathology)' |
| test_merged | 372 | 'URINE FOR SODIUM(SPOT/24 HOURS)' merged into 'URINE FOR SODIUM(SPOT/24 HOURS)' (old #370): same name, department and price |
| test_renamed | 381 | 'ALBUMIN' clashes with old #312 (Pathology, 150.00); named 'ALBUMIN (Pathology)' |
| test_renamed | 396 | 'QUANTIFERON TB GOLD' clashes with old #255 (Pathology, 4900.00); named 'QUANTIFERON TB GOLD (Pathology)' |
| test_renamed | 428 | 'SERUM AMMONIA' clashes with old #425 (Pathology, 850.00); named 'SERUM AMMONIA (Pathology)' |
| test_renamed | 436 | 'CHOLESTEROL TOTAL' clashes with old #116 (Pathology, 250.00); named 'CHOLESTEROL TOTAL (Pathology)' |
| test_renamed | 588 | 'MAMMOGRAPHY' clashes with old #486 (Radiology, 1400.00); named 'MAMMOGRAPHY (Radiology)' |
| test_renamed | 615 | 'USG OF PREGNANCY PROFILE & ANOMALY SCAN' clashes with old #58 (Echo & USG, 2000.00); named 'USG OF PREGNANCY PROFILE & ANOMALY SCAN (Radiology)' |
| test_merged | 617 | 'PET X RAY' merged into 'PET X RAY' (old #616): same name, department and price |
| test_renamed | 618 | 'DIGITAL MCU/ASU' clashes with old #484 (Radiology, 2500.00); named 'DIGITAL MCU/ASU (Radiology)' |
| test_renamed | 628 | 'EACH LIMB DOPPLER STUDY (ARTERIAL)' clashes with old #577 (Echo & USG, 1800.00); named 'EACH LIMB DOPPLER STUDY (ARTERIAL) (Radiology)' |
| test_renamed | 629 | 'USG OF SOFT TISSUE' clashes with old #582 (Echo & USG, 1800.00); named 'USG OF SOFT TISSUE (Radiology)' |
| test_renamed | 630 | 'EACH LIMB DOPPLER STUDY (VENOUS)' clashes with old #576 (Echo & USG, 1800.00); named 'EACH LIMB DOPPLER STUDY (VENOUS) (Radiology)' |
| test_renamed | 631 | 'USG BILATERAL RENAL DOPPLER STUDY' clashes with old #442 (Echo & USG, 1600.00); named 'USG BILATERAL RENAL DOPPLER STUDY (Radiology)' |
| test_renamed | 632 | 'USG BILATERAL RENAL DOPPLER STUDY' clashes with old #442 (Echo & USG, 1600.00); named 'USG BILATERAL RENAL DOPPLER STUDY (old #632)' |
| age_unreadable | 3486 | age '700' (out_of_range); left empty |
| test_missing | 56 | bill #29 (old no. 24): test #248 no longer exists; kept as 'Unknown test (old #248)' |
| test_missing | 99 | bill #44 (old no. 39): test #240 no longer exists; kept as 'Unknown test (old #240)' |
| test_missing | 119 | bill #55 (old no. 50): test #248 no longer exists; kept as 'Unknown test (old #248)' |
| test_missing | 144 | bill #68 (old no. 63): test #240 no longer exists; kept as 'Unknown test (old #240)' |
| test_missing | 220 | bill #97 (old no. 92): test #240 no longer exists; kept as 'Unknown test (old #240)' |
| test_missing | 253 | bill #110 (old no. 105): test #340 no longer exists; kept as 'Unknown test (old #340)' |
| test_missing | 293 | bill #130 (old no. 125): test #240 no longer exists; kept as 'Unknown test (old #240)' |
| test_missing | 310 | bill #132 (old no. 127): test #240 no longer exists; kept as 'Unknown test (old #240)' |
| test_missing | 325 | bill #141 (old no. 136): test #240 no longer exists; kept as 'Unknown test (old #240)' |
| test_missing | 334 | bill #142 (old no. 137): test #240 no longer exists; kept as 'Unknown test (old #240)' |
| test_missing | 464 | bill #196 (old no. 191): test #240 no longer exists; kept as 'Unknown test (old #240)' |
| test_missing | 528 | bill #231 (old no. 226): test #240 no longer exists; kept as 'Unknown test (old #240)' |
| test_missing | 997 | bill #420 (old no. 414): test #240 no longer exists; kept as 'Unknown test (old #240)' |
| test_missing | 1018 | bill #423 (old no. 417): test #240 no longer exists; kept as 'Unknown test (old #240)' |
| test_missing | 1026 | bill #424 (old no. 418): test #248 no longer exists; kept as 'Unknown test (old #248)' |
| test_missing | 1028 | bill #424 (old no. 418): test #240 no longer exists; kept as 'Unknown test (old #240)' |
| test_missing | 1532 | bill #657 (old no. 650): test #240 no longer exists; kept as 'Unknown test (old #240)' |
| test_missing | 1827 | bill #786 (old no. 779): test #248 no longer exists; kept as 'Unknown test (old #248)' |
| test_missing | 1859 | bill #800 (old no. 793): test #248 no longer exists; kept as 'Unknown test (old #248)' |
| test_missing | 2010 | bill #875 (old no. 868): test #240 no longer exists; kept as 'Unknown test (old #240)' |
| test_missing | 2016 | bill #877 (old no. 870): test #240 no longer exists; kept as 'Unknown test (old #240)' |
| test_missing | 2145 | bill #941 (old no. 934): test #248 no longer exists; kept as 'Unknown test (old #248)' |
| test_missing | 2181 | bill #957 (old no. 950): test #593 no longer exists; kept as 'Unknown test (old #593)' |
| test_missing | 2230 | bill #988 (old no. 981): test #248 no longer exists; kept as 'Unknown test (old #248)' |
| invoice_no_duplicate | 2214 | old bill no. 2202 is used more than once; this one is SHC/2026-27/002202-B |
| test_missing | 7855 | bill #3784 (old no. 3765): test #270 no longer exists; kept as 'Unknown test (old #270)' |
| test_missing | 7893 | bill #3800 (old no. 3781): test #270 no longer exists; kept as 'Unknown test (old #270)' |
| invoice_no_duplicate | 4152 | old bill no. 4127 is used more than once; this one is SHC/2026-27/004127-B |
| invoice_no_duplicate | 4153 | old bill no. 4128 is used more than once; this one is SHC/2026-27/004128-B |

## Reconciliation

- Everything matches.
