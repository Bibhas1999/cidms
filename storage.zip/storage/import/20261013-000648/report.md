# Data move from the old app: supreme

- When: 20261013-000648
- Mode: saved
- Reconciliation: OK

## Rows in and out

| table | old rows | created | already there | merged | left out |
|---|---:|---:|---:|---:|---:|
| users | 5 | 0 | 5 | 0 | 0 |
| departments | 7 | 0 | 7 | 0 | 0 |
| test_types | 5 | 0 | 5 | 0 | 0 |
| tests | 601 | 2 | 594 | 5 | 0 |
| referring_doctors | 763 | 7 | 731 | 25 | 0 |
| patients | 5042 | 67 | 4959 | 16 | 0 |
| invoices | 4879 | 78 | 4801 | 0 | 0 |
| invoice_items | 9942 | 132 | 9810 | 0 | 0 |
| payments | 3728 | 62 | 3666 | 0 | 0 |

Referring doctors: 763 spellings grouped into 738 doctors (see doctors.csv). For doctors, 'old rows' counts spellings.

## Decisions applied

- Departments and test types renamed to the new spelling (e.g. ECHO&USG -> Echo & USG, CT-SCAN -> CT scan); X-ray, CT scan and USG are imaging.
- Test names trimmed with spaces collapsed. Same name (any case) in the same department at the same price: merged into one test. Otherwise the later one is renamed '<name> (<Department>)', or '<name> (old #<id>)' if that is taken too.
- Bill lines pointing at a test that no longer exists keep their price as 'Unknown test (old #<id>)' with no test or department.
- Referring doctors grouped on a key (upper case, 'DR' prefix, dots and commas removed, spaces collapsed, single initials joined); SELF, NA, NONE, '-' and blank mean no doctor. Shown under the most used spelling in nice case, with 'Dr.' when any spelling had it.
- Customers merged into one patient only when the name (upper case, spaces collapsed) and the last 10 digits of a 10+ digit mobile match. Patient numbers follow each patient's earliest old customer id.
- A merged patient's details (name, age, gender, mobile, address, C/O, email) come from the latest customer row; created_at from the earliest.
- Ages: whole numbers kept; decimals ('1.5') rounded down to whole years; months/days converted to whole years; anything else left empty.
- Bill numbers: <prefix>/<financial year>/<old number, 6 digits>; a repeated old number keeps the plain form on the lowest old id and the later ones get -B, -C.
- Bill total = old payments.total_amount; the difference from the lines' total is the discount (type 'amount').
- Payments: only old payment rows with an amount above zero; online -> UPI with the note 'Online (old system)'.
- Staff: emails lower-cased; an existing account with the same email is kept as it is and only linked. New accounts keep the old bcrypt password (replaced at first sign-in) and must change it. Admin -> owner, Manager -> admin, Receptionist -> receptionist, User -> technician.
- Running numbers continue after the highest imported patient number and, per financial year, the highest old bill number.
- Counter invoice:2025-26 set to at least 752.
- Counter invoice:2026-27 set to at least 5027.
- Counter patient set to at least 3991.

## Issues (5)

- test_merged: 5

| kind | old id | detail |
|---|---:|---|
| test_merged | 71 | 'URINE FOR CHYLOMICRONS' merged into 'URINE FOR CHYLOMICRONS' (old #70): same name, department and price |
| test_merged | 293 | 'STOOL RE' merged into 'STOOL RE' (old #63): same name, department and price |
| test_merged | 360 | 'ToRCH IgG' merged into 'ToRCH IgG' (old #356): same name, department and price |
| test_merged | 372 | 'URINE FOR SODIUM(SPOT/24 HOURS)' merged into 'URINE FOR SODIUM(SPOT/24 HOURS)' (old #370): same name, department and price |
| test_merged | 617 | 'PET X RAY' merged into 'PET X RAY' (old #616): same name, department and price |

## Reconciliation

- Everything matches.
